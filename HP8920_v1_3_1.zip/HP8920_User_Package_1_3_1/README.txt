HP 8920A / 8920B Control & Logger - Freeware 1.3.1
By Walter Cista

INSTALL
1. Extract the whole public ZIP. Keep all files and assets together.
2. Double-click Setup.exe. Read the safety disclaimer and tick the unchecked
   acknowledgement box. Agree and continue remains disabled until you do.
   Choose a writable destination and install. Cancel exits without installing.
3. Launch from the Start Menu or optional desktop shortcut.
4. Connect Prologix GPIB-USB, select its COM port and the instrument GPIB address.
5. Press Connect. The app detects an HP 8920A or 8920B.

Windows 11 and the .NET Framework 4.x Windows components are required.
No compiler, Python, source code or paid development software is needed by users.
8920A requires its GPIB/remote interface hardware (Option 103).
If no COM appears, install the official FTDI virtual COM port driver using
Prologix support: https://prologix.biz/resources/frequently-asked-questions/gpib-usb-controller-faq/

FREEWARE AND STARTUP NOTICE
Use is free, without a trial expiry. Optional support: https://paypal.me/WCista
Without a valid unlock code, the notice appears on every startup, starting at
10 seconds and increasing by one second per complete installed day to a maximum
of 30 seconds. It then closes automatically and the main application opens.
No payment is required to continue. The app does not check PayPal payments.
Run Setup.exe again to reinstall: this resets the timer to 10 seconds, creates
a new installation ID and invalidates the previous installation unlock code.
Simply copying/replacing the EXE is not a reinstall and does not reset the timer.

REMOVE THE NOTICE
Press Copy request ID and send the complete ID to walter.cista@gmail.com.
Walter issues codes manually. Press Enter unlock code, paste the whole code and
Activate. Only a valid code for that installation and PC/current Windows user
removes the startup notice. Other installations need another code.
The main window also has Donate and Unlock startup notice buttons.
No email, activation request or payment is sent automatically.

USE
Read the included HP8920_Installation_and_Usage.pdf, also accessible through
Instructions PDF. It explains connections, panels, presets, live graphs,
CSV logging, timing, reinstall behavior and unlock codes.
Read LICENSE.txt for the freeware licence and unchanged redistribution terms.
DISCLAIMER.txt contains the safety notice displayed before installation.
Original header/front artwork is decorative and is not an exact port map.
Follow the connector labels, manufacturer limits and installed options on your unit.

VALIDATION
Application, Setup and private issuer binaries were successfully compiled
with Mono's C# compiler as .NET Framework-compatible Windows assemblies.
Fourteen checks passed for countdown boundaries, the 30-second cap, clock
rollback handling, signatures, rejected tampered codes and installation binding.
Windows GUI/installer operation and real Prologix/test-set operation have not
been verified in the authoring environment. Validate on your Windows PC and
instrument before relying on measurements or wider public distribution.
These executables are not Authenticode-signed. Activation-code signing is a
separate mechanism and does not provide Windows publisher certification.
